# API First 开发规范

> 本规范适用于前端、后端、测试和 AI 辅助开发全过程。

## 1. 目标

API First 的目标不是先写一份形式化文档，而是让前端、后端和测试在开发前对以下内容形成共同契约：

- 资源与路径
- 请求方法
- 请求字段
- 响应字段
- 状态码
- 错误结构
- 枚举值
- 异步任务模式
- 幂等规则
- 示例数据

本项目的正式接口契约为：

`api/openapi_mvp.yaml`

## 2. 契约优先流程

```text
用例与页面流程
    ↓
资源模型与状态机
    ↓
OpenAPI Path / Schema / Example
    ↓
API Review
    ↓
Contract Freeze
    ↓
前端 Mock 与类型
    ↓
后端实现
    ↓
Contract Test
    ↓
真实接口联调
```

任何新增接口或字段变更都必须先更新 OpenAPI。

## 3. 资源设计原则

主要资源：

- `system-mappings`
- `connectors`
- `release-cases`
- `alert-cases`
- `task-runs`
- `evidence`
- `checklist-results`

业务动作采用子资源或动作端点，例如：

```text
POST /api/release-cases/{id}/collect
POST /api/release-cases/{id}/publish-confluence
POST /api/release-cases/{id}/create-change-request
POST /api/alert-cases/{id}/analyze
```

动作端点必须说明：

- 是否同步或异步
- 是否具备副作用
- 是否需要用户确认
- 是否支持重复调用
- 幂等策略

## 4. 异步任务约定

长耗时操作统一返回：

```http
HTTP/1.1 202 Accepted
Content-Type: application/json
```

```json
{
  "taskRunId": "3adb56b1-1d23-4d22-b77e-43ec52242252",
  "status": "pending"
}
```

前端通过：

```text
GET /api/task-runs/{taskRunId}
```

轮询状态。

任务状态枚举：

- `pending`
- `running`
- `waiting_for_user`
- `completed`
- `failed`
- `cancelled`

任务步骤状态枚举：

- `pending`
- `running`
- `success`
- `warning`
- `failed`
- `skipped`

## 5. 统一错误模型

所有非 2xx 业务响应使用：

```json
{
  "error": {
    "code": "CONNECTOR_TIMEOUT",
    "message": "Jenkins 请求超时。",
    "retryable": true,
    "details": {
      "connector": "jenkins"
    },
    "requestId": "req-123"
  }
}
```

要求：

- `code` 稳定，供前端判断
- `message` 可安全展示给用户
- `retryable` 明确是否可重试
- `details` 不得包含 Secret
- `requestId` 用于日志关联

常用错误码：

- `VALIDATION_ERROR`
- `NOT_FOUND`
- `CONFLICT`
- `INVALID_STATE`
- `CONFIGURATION_ERROR`
- `AUTHENTICATION_FAILED`
- `PERMISSION_DENIED`
- `CONNECTOR_TIMEOUT`
- `CONNECTOR_UNAVAILABLE`
- `EXTERNAL_WRITE_FAILED`
- `AI_OUTPUT_INVALID`
- `TASK_ALREADY_RUNNING`

## 6. 命名约定

### JSON

使用 `camelCase`：

```json
{
  "releaseCaseId": "...",
  "plannedTime": "...",
  "systemMappingId": "..."
}
```

### Python

内部使用 `snake_case`，通过 Pydantic Alias 转换为 `camelCase`。

### TypeScript

保持与 API 一致，使用 `camelCase`。

## 7. 分页约定

列表接口统一使用：

```text
?page=1&pageSize=20
```

响应：

```json
{
  "items": [],
  "page": 1,
  "pageSize": 20,
  "total": 0
}
```

MVP 数据量较小，但保留统一结构可避免后续破坏性修改。

## 8. 时间与 ID

- ID 使用 UUID 字符串
- 时间统一 ISO 8601
- 数据库存储 UTC
- API 返回包含时区的 UTC 时间
- 前端按用户本地时区显示

## 9. 幂等性

以下操作必须考虑幂等：

- xMatters Webhook：使用外部 Alert ID 去重
- 创建 Confluence 页面：保存目标 Page ID
- 创建 Change Request：保存外部 Change ID
- 启动收集任务：同一 Case 同类型活动任务最多一个

具有写副作用的接口可支持：

```http
Idempotency-Key: <uuid>
```

## 10. OpenAPI 维护规则

### 必须包含

- `operationId`
- 请求和响应 Schema
- 状态码
- 错误响应
- 枚举
- 必要示例
- 接口描述
- 是否异步

### 版本管理

MVP 期间使用：

```text
/api/...
```

暂不增加 URL 版本号。发生不兼容变更前再引入 `/api/v2`。

### 合约冻结

每个开发迭代开始前冻结当前接口版本。

冻结后若必须修改：

1. 提交 OpenAPI 变更
2. 标明影响范围
3. 前后端共同确认
4. 更新 Mock 与类型
5. 再修改代码

## 11. 前端使用方式

首期不引入 TanStack Query。

前端使用：

- OpenAPI 生成 TypeScript 类型
- 手写轻量 `fetch` Client
- 固定 JSON Fixture / Mock Transport
- React Hooks 管理 Loading、Error 和轮询

推荐仅引入开发期工具：

```text
openapi-typescript
```

生成文件不得手工修改。

## 12. 后端使用方式

FastAPI 路由、Pydantic Schema 和状态码必须匹配 OpenAPI。

建议增加 CI 校验：

- OpenAPI YAML 语法检查
- FastAPI 生成 OpenAPI 与契约差异检查
- API 示例响应 Schema 校验
- 关键接口契约测试

## 13. API Review Checklist

- 路径是否表达资源和动作？
- 是否可以使用已有资源而无需增加接口？
- 请求字段是否最小化？
- 枚举是否明确？
- 错误码是否覆盖失败场景？
- 长任务是否返回 202？
- 是否提供幂等策略？
- 是否提供外部链接字段？
- 是否泄露第三方原始响应？
- 是否支持部分数据源失败？
