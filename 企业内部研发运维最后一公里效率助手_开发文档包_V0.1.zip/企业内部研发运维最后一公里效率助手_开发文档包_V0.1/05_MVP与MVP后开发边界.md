# MVP 与 MVP 后开发边界

## 1. MVP 判断原则

一个功能进入 MVP，必须至少满足一项：

- 是 Release 端到端闭环的必要步骤
- 是 Alert 端到端闭环的必要步骤
- 是安全、可靠性或数据追溯的必要能力
- 没有它就无法进行真实用户验证

仅仅“以后可能需要”不能作为进入 MVP 的理由。

## 2. MVP 范围

### 共享基础

- React + TypeScript + Ant Design
- FastAPI + Pydantic
- PostgreSQL
- Python Worker
- LangChain + LangGraph
- OpenAPI
- 结构化日志
- System Mapping
- Connector Config
- Task Run
- Evidence Reference

### Release MVP

- 创建 Release Case
- Jira 读取
- Jenkins Build / Test 摘要
- 基础 Ansible Job 信息
- 固定 Checklist
- AI Release 草稿
- 用户编辑和确认
- Confluence 创建或更新
- Change Request 草稿与创建或导出
- Evidence Snapshot

### Alert MVP

- xMatters Webhook
- System Mapping
- Elasticsearch 查询
- Prometheus 查询
- 最近 Jenkins / Release / Change
- Runbook 链接或摘要
- AI 事件摘要
- 最多三个原因假设
- 用户最终原因和反馈

## 3. MVP 后优先细化

### Release

- 多种 Release 类型
- 多模板继承
- 多 Jenkins Job
- 更丰富测试制品
- 数据库 / Feature Flag Change
- 历史 Release 对比
- 更细的 Checklist 管理
- Change Request 更新和关闭

### Alert

- 更多告警类型
- Email 接入兼容
- 历史 Incident 检索
- 相似告警
- Alert Grouping
- 服务依赖
- 更多指标和日志模板
- 通知回传
- 告警处理时间线

### Jenkins Job Assistant

- 从本系统触发已有 Job
- 参数白名单
- 执行进度
- Console 摘要
- 测试截图和制品
- Release 自动关联

## 4. 明确延期的架构能力

以下内容必须有实际问题后再引入：

| 能力 | 触发条件 |
|---|---|
| TanStack Query | 前端服务端状态管理明显复杂 |
| Redis | 缓存或任务吞吐出现明确瓶颈 |
| 专用消息队列 | PostgreSQL Task Table 无法满足并发 |
| SSE / WebSocket | 轮询对用户体验或服务压力不再可接受 |
| 微服务 | 模块需要独立团队、独立扩缩容或独立部署 |
| Kubernetes | 单机 / Compose 无法满足可用性和发布要求 |
| 向量数据库 | 历史 Runbook / Incident 规模和检索质量需要 |
| 自由 Agent | 固定流程无法覆盖且风险治理成熟 |
| 复杂 RBAC | 用户和资源边界明显增加 |

## 5. MVP 后迭代顺序建议

1. 修复 MVP 真实使用问题
2. 优化 Connector 稳定性和字段映射
3. 增加 Release 模板和 Checklist
4. 增加 Alert 类型和历史经验
5. Jenkins Job Assistant
6. 需求分析
7. 再评估基础设施扩展

## 6. 防止范围膨胀的问题清单

新增需求进入开发前必须回答：

- 现有企业平台是否已经提供？
- 能否通过 Connector 或 Deep Link 解决？
- 是否直接减少当前用户的人工操作？
- 是否属于首批 1–2 个系统的真实场景？
- 是否需要新增基础设施？
- 是否会把固定工作流变成通用平台？
- 是否具备明确验收指标？
