# MVP 开发路线图与阶段拆分

## 1. 总体策略

开发分为四个技术阶段：

1. 阶段一：前后端基础架构与基本测试
2. 阶段二：前端具体开发
3. 阶段三：后端具体开发
4. 阶段四：前后端接口联调与 MVP 验收

API First 是贯穿四个阶段的主线。

阶段二与阶段三在管理上分开描述，但在 API 合约冻结后可以并行进行。

## 2. MVP 业务切片

MVP 不追求覆盖所有系统和所有配置，优先完成两个纵向切片。

### MVP-A：Release Preparation

必须形成端到端闭环：

```text
创建 Release Case
→ 收集 Jira / Jenkins 基础信息
→ Checklist
→ AI Release 草稿
→ 用户确认
→ Confluence 发布
→ Change Request 草稿与创建
→ Evidence Snapshot
```

首期可限制：

- 1 至 2 个系统
- 1 套 Release 模板
- 1 种 Change Request 类型
- 固定 Jira / Jenkins 映射

### MVP-B：Alert Triage

必须形成端到端闭环：

```text
接收 xMatters 告警
→ 匹配系统
→ 查询 Elasticsearch
→ 查询 Prometheus
→ 关联最近 Jenkins / Release
→ AI 摘要与最多三个假设
→ 用户填写最终原因和反馈
```

首期可限制：

- 1 个业务系统
- 1 至 3 种高频告警
- 固定 Elasticsearch 查询模板
- 固定 PromQL
- 只读分析

## 3. 阶段依赖

```mermaid
flowchart LR
    P1[阶段一 基础架构与 API 合约] --> P2[阶段二 前端开发]
    P1 --> P3[阶段三 后端开发]
    P2 --> P4[阶段四 接口联调]
    P3 --> P4
    P4 --> MVP[MVP 发布]
    MVP --> POST[MVP 后细化开发]
```

## 4. 阶段一：基础架构与测试

### 目标

建立可持续开发的最小工程骨架，并冻结 MVP API 合约。

### 主要输出

- Monorepo 或统一代码仓库结构
- React + TypeScript + Ant Design 可启动
- FastAPI + Pydantic 可启动
- PostgreSQL + Alembic 可用
- Python Worker 可启动
- 统一日志与错误模型
- OpenAPI MVP 合约
- 前端 Mock 数据与最小页面
- 后端健康检查与最小资源接口
- CI 基础检查

### 退出条件

- 前端、API、Worker、PostgreSQL 本地可一键启动
- `/health/live` 和 `/health/ready` 通过
- OpenAPI 通过评审并冻结
- 前端可从 Mock 显示 Release Case 示例
- 后端返回与契约一致的示例响应
- 前后端基础测试均通过

## 5. 阶段二：前端开发

### 目标

在不依赖后端完成度的前提下，依据 OpenAPI 和 Mock 数据完成 MVP 页面。

### Release MVP 页面

- Release Case 列表
- 创建 Release Case
- Release 详情
- 数据收集进度
- Jira / Jenkins 证据
- Checklist
- AI 草稿编辑
- Confluence 发布确认
- Change Request 预览与确认

### Alert MVP 页面

- Alert Case 列表
- Alert 详情
- 日志、指标、最近变更 Tabs
- AI 摘要与假设
- 信息缺口
- 最终原因与反馈

### 配置和运维页面

- 最小 System Mapping
- Connector 测试
- Task Run 详情

### 退出条件

- 所有 MVP 页面使用 Mock 完成主流程
- 页面类型来自 OpenAPI
- Loading、Empty、Error、Partial Failure 状态齐全
- 关键组件测试通过
- 不依赖后端私有字段

## 6. 阶段三：后端开发

### 目标

按照冻结 OpenAPI 完成数据模型、Connector、任务执行、规则和 AI 工作流。

### 共享基础

- SQLAlchemy 模型与迁移
- Repository
- PostgreSQL Task Queue
- Worker 任务领取与恢复
- Connector 基类
- LangChain Gateway
- LangGraph Checkpoint
- 统一错误和日志

### Release MVP

- Release Case API
- Jira Connector
- Jenkins Connector
- 基础 Ansible 信息读取
- Checklist Evaluator
- Release LangGraph
- AI Release Draft
- Confluence Connector
- Change Request Connector
- Evidence Snapshot

### Alert MVP

- xMatters Webhook
- System Mapping
- Elasticsearch Connector
- Prometheus Connector
- 最近 Build / Release 查询
- Alert LangGraph
- AI 摘要与假设
- 用户反馈

### 退出条件

- 后端契约测试通过
- 单元与集成测试通过
- 所有接口状态码和错误体符合 OpenAPI
- Connector 具备 Timeout、重试和脱敏日志
- 长任务不阻塞 FastAPI 请求
- 写操作具备幂等保护

## 7. 阶段四：接口联调与验收

### 目标

将前端从 Mock 切换到真实 API，完成端到端验证。

### 主要工作

- OpenAPI 差异检查
- 重新生成 TypeScript 类型
- 替换 Mock Transport
- 字段、枚举和时间格式联调
- 异步 TaskRun 轮询
- 部分失败展示
- External Deep Link
- Release E2E
- Alert E2E
- UAT
- 部署验证

### MVP 发布门槛

- Release 核心链路通过
- Alert 核心链路通过
- 无 P0/P1 缺陷
- Secret 未出现在日志和前端
- 数据源失败有降级表现
- 用户可追溯关键证据
- Change Request 与 Confluence 写入需人工确认
- 生产环境具备基本监控和回滚方案

## 8. 参考工作量

以下仅作为单人全栈开发并使用 AI 辅助时的粗略规划单位，不是交付承诺。

| 阶段 | 参考范围 |
|---|---:|
| 阶段一 | 4–7 人日 |
| 阶段二 | 8–14 人日 |
| 阶段三 | 12–22 人日 |
| 阶段四 | 5–10 人日 |

外部系统 API、权限和网络环境不确定时，应额外预留技术验证时间。

## 9. 实施建议

- 不按“所有前端完成后才开始后端”执行。
- 阶段一冻结 API 后，阶段二和阶段三并行。
- 每周至少完成一个纵向可演示切片。
- Release 优先于 Alert。
- 每个 Connector 先用真实只读接口做 Spike，再纳入正式开发。
